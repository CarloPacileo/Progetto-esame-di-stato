<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nome Filiale</th>
          <th>Città</th>
          <th>saldo</th>
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT F.id_Filiale, F.nome, AVG(CL.Saldo) as saldomedio
FROM C_CORRENTE CL, Filiale F
WHERE F.id_Filiale = CL.id_Filiale 
GROUP BY F.Nome
ORDER BY AVG(CL.saldo) DESC
limit 1
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["id_Filiale"] . "</td><td>" . $row["nome"] . "</td><td>" . $row["saldomedio"] . "</td><td>". "</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>