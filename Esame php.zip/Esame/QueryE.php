<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nome Filiale</th>
          <th>Città</th>
          
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT F.nome, F.Città
FROM FILIALE F
WHERE F.Patrimonio > ANY(SELECT MIN(F.Patrimonio)
                         FROM FILIALE F
                        WHERE F.Città='Milano')";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["nome"] . "</td><td>" . $row["Città"] . "</td><td>" ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>