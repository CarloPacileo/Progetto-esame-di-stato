<?php
session_start();
include "connessione.php";


$u = $_POST['utente'];
$p = $_POST['password']; //Vengono passati i parametri di username e password tramite il metodo POST

$sql ="select * from accesso_clienti where username = \"$u\" and password =\"$p\" "; //Query che viene effettuata al database

$ris = mysqli_query($connessione, $sql);

$_SESSION['username'] = $u;
if (mysqli_num_rows($ris) === 1) {
			$row = mysqli_fetch_assoc($ris);
            if ($row['Username'] === $u && $row['Password'] === $p) {
            	$_SESSION['username'] = $row['Username'];
            	$_SESSION['C_fiscale'] = $row['C_fiscale'];
            	header("Location: principale.html");
		        exit();
            }else{
				header("Location: accesso.php?error=Username o Password errati");
		        exit();
			}
		}else{
			header("Location: accesso.php?error=Username o Password errati");
	        exit();
		}

