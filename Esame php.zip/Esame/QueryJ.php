<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nome Filiale</th>
          <th>codice filiale</th>
          
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT F.Nome, F.id_filiale
               FROM FILIALE F
               WHERE F.Patrimonio > ANY ( SELECT F.Patrimonio
                                        FROM FILIALE F
                                        WHERE F.Città = 'Napoli')
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Nome"] . "</td><td>" . $row["id_filiale"] . "</td><td>" ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>