<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nominativo</th>
        
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT DISTINCT C.Nominativo
FROM CLIENTE C
WHERE C.C_fiscale IN (SELECT CC.C_fiscale
                             FROM C_CLIENTI CC)
AND C.C_fiscale NOT IN (SELECT PC.C_fiscale                             
                             FROM P_CLIENTI PC)";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Nominativo"] ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>