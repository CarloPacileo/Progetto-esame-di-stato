<!DOCTYPE html>
<html>
<head>
  <title>LOGIN</title>
  <link rel="stylesheet" type="text/css" href="stile.css">
</head>
<body>
<div class="wrapper">
  <img src="banca.png">
  <h1> Intesa Sanpaolo </h1>
  <div id="formContent">
<h2 > Login </h2>
      <?php if (isset($_GET['error'])) { ?>
        <p><?php echo $_GET['error']; ?></p>
      <?php } ?> 
     <form action="login.php" method="post">
      <input type="text" id="login"  name="utente" placeholder="utente">
      <input type="password" id="password" name="password" placeholder="password">

      <input type="submit" value="Accedi">
    </form>

  </div>
</div>
</body>
</html>