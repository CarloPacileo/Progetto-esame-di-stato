<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nominativo</th>
         
          
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT DISTINCT C.nominativo
FROM CLIENTE C, C_CLIENTI CC, FILIALE F, C_CORRENTE CL
WHERE C.C_fiscale=CC.C_fiscale
AND F.Id_filiale=CL.Id_filiale
AND CC.id_conto=CL.id_conto
AND F.Città='Firenze'
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["nominativo"] . "</td><td>"  ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>