<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nominativo</th>
          <th>Codice fiscale</th>
          <th>Prestito</th>
          <th>Codice prestito</th>
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT C.Nominativo, C.C_fiscale,P.importo,PC.id_prestito
FROM PRESTITO P, P_CLIENTI PC, CLIENTE C
WHERE P.id_prestito=PC.id_prestito
AND C.C_fiscale=PC.C_fiscale 
ORDER BY C.Nominativo";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Nominativo"] . "</td><td>" . $row["C_fiscale"] . "</td><td>" . $row["importo"] . "</td><td>" . $row["id_prestito"] ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>