<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Importo</th>
          <th>Ufficio</th>
          <th>Data inizio</th>
          <th>Data fine</th>
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT PR.Importo, PR.Ufficio, PR.Data_inizio, PR.Data_fine FROM p_clienti PC, prestito PR WHERE PC.C_fiscale= \"$cf\" AND PC.id_prestito=PR.id_prestito";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Importo"] . "</td><td>" . $row["Ufficio"] . "</td><td>" . $row["Data_inizio"] . "</td><td>" . $row["Data_fine"] ."</td></tr>";
                    
               }

          }else{
               //La query non ha risultato
             exit();
          }
     
     ?>

</table>
</body>
</html>
