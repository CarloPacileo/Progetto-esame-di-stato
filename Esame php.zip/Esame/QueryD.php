<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>codice filiale</th>
          <th>numero dei titolari di conti correnti</th>
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT F.Id_filiale, COUNT(C.C_fiscale) AS numero 
FROM FILIALE F, CLIENTE C, C_CORRENTE CL,C_CLIENTI CC
WHERE C.C_fiscale=CC.C_fiscale
AND F.Id_filiale=CL.Id_filiale
AND CL.id_conto=CC.id_conto
GROUP BY F.Id_filiale 
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Id_filiale"] . "</td><td>" . $row["numero"] . "</td><td>" ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>