<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Numero Titolari</th>
          
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT COUNT(DISTINCT CC.C_Fiscale) as Num_Titolari
FROM C_CLIENTI CC, (SELECT CL.id_Conto
                            FROM C_CORRENTE CL, (SELECT CL.id_filiale 
                                                  FROM C_CORRENTE CL
                                                       GROUP BY CL.Id_filiale
                                                       HAVING AVG(CL.Saldo) >=6500) AS CF                    
                             WHERE CL.Id_filiale=CF.Id_filiale) AS H 
WHERE CC.id_conto=H.id_conto
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Num_Titolari"] ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>