<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Saldo</th>
          <th>Nominativo</th>
          <th>codice fiscale</th>
          
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT AVG(CL.saldo) AS Saldomedio, C.nominativo, C.C_fiscale
FROM C_CORRENTE CL, CLIENTE C, C_CLIENTI CC
WHERE CL.id_conto=CC.id_conto
AND C.C_fiscale=CC.C_fiscale
AND C.città='Napoli'
GROUP BY C.nominativo
HAVING COUNT(CL.Saldo)>=2
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Saldomedio"] . "</td><td>" . $row["nominativo"] . "</td><td>" . $row["C_fiscale"] . "</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>