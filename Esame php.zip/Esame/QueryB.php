<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nominativo</th>
         
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT DISTINCT C.Nominativo
FROM CLIENTE C, P_CLIENTI PC, C_CLIENTI CC
WHERE C.C_fiscale=PC.C_fiscale
AND C.C_fiscale=CC.C_fiscale
 ";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Nominativo"]."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>