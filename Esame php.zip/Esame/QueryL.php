<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>codice filiale</th>
          <th>Nome filiale</th>
          <th>Saldo medio</th>
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT F.id_Filiale, F.Nome, AVG(CL.Saldo) AS Saldo_Medio
FROM C_CORRENTE CL, FILIALE F
WHERE F.id_Filiale = CL.id_Filiale
GROUP BY CL.id_Filiale
HAVING AVG(CL.Saldo) >=5000
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["id_Filiale"] . "</td><td>" . $row["Nome"] . "</td><td>" . $row["Saldo_Medio"] ."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>