<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>


<table>
     <tr>
          <th>Saldo</th>
          <th>Id_filiale</th>
          <th>Nome filiale</th>
          <th>Città della filiale</th>
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT CL.saldo, Cl.Id_filiale, F.Nome, F.Città FROM C_CORRENTE CL, C_CLIENTI CC, Filiale F WHERE CC.C_fiscale= \"$cf\" AND CL.Id_filiale= F.Id_filiale AND CC.id_conto=CL.id_conto";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["saldo"] . "</td><td>" . $row["Id_filiale"] . "</td><td>" . $row["Nome"] . "</td><td>" . $row["Città"] ."</td></tr>";
                    
               }

          }else{
               //La query non ha risultato
             exit();
          }
     
     ?>

</table>
</body>
</html>