

<?php
session_start();
include "connessione.php";
$nome = $_SESSION['username'];
$cf= $_SESSION['C_fiscale'];

$sql ="SELECT Nominativo, Indirizzo, Città, N_telefono FROM cliente WHERE C_fiscale= \"$cf\""; 			//Query che viene effettuata al database

$ris = mysqli_query($connessione, $sql);

if (mysqli_num_rows($ris) === 1) {
			$row = mysqli_fetch_assoc($ris);
            $nome= $row['Nominativo'];
            $_SESSION['Nominativo'] = $row['Nominativo'];
            $città = $row['Città'];
            $telefono= $row['N_telefono'];
        }
?>
<html>
<head>
<style>
	body {
		background: #56baed;

		justify-content: center;
		align-items: left;
		flex-direction: column;
	}
	*{
		font-family: sans-serif;
		box-sizing: border-box;
	}
	h1 {
		text-align: left;
  		font-weight: 600;
		text-shadow: 2px 2px #808080;
  		color: #D3D3D3
	}

	h2 {
		color: #fff;
		text-shadow: 2px 2px #525252;
		text-align: left;
		font-size: 24px;
	}
	a {
		margin-left: 10px;
		color: #fff;
		text-shadow: 2px 2px #525252;
		text-align: left;
		font-size: 24px;

	}
	a:hover{
		opacity: .8;
	}
</style>
</head>
 <body>


<br><h1> Informazioni Personali <h1>
<h2> Nome: <?php echo $nome; ?></h2>
<h2> Città: <?php echo $città; ?></h2>
<h2> Codice Fiscale: <?php echo $cf; ?>	</h2>
<h2> Numero Di Telefono: <?php echo $telefono; ?>	</h2>

<br>
	 <a href="esci.php" target="principale">Logout</a>
</body>
</html>