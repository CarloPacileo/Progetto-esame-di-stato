<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" type="text/css" href="cssQuery.css">
</head>
<body>

<table>
     <tr>
          <th>Nominativo</th>
          <th>Codice fiscale</th>
          <th>Numero depositi</th>
     </tr>
     <?php 
          session_start();
          include "connessione.php";

          $cf= $_SESSION['C_fiscale'];
          $sql = "SELECT DISTINCT C.Nominativo,C.C_fiscale, COUNT(CC.C_fiscale) as N_Depositi
                    FROM CLIENTE C, FILIALE F, C_CORRENTE CL, C_CLIENTI CC
                    WHERE C.C_fiscale=CC.C_fiscale
AND F.id_filiale=CL.id_filiale
AND CL.id_conto=CC.id_conto
AND F.nome= 'Filiale di Capena'
AND F.città= 'Roma'
GROUP BY C.Nominativo
HAVING N_Depositi = 1
";
          
          $result = mysqli_query($connessione, $sql);


          if (mysqli_num_rows($result) >= 1) {

               while($row = mysqli_fetch_array($result)) {
                    echo "<tr><td>". $row["Nominativo"] . "</td><td>" . $row["C_fiscale"] . "</td><td>" . $row["N_Depositi"]."</td></tr>";
                    
               }

          }else{
               
             exit();
          }
     
     ?>